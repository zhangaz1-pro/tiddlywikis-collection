# TW5-TriggerActions
A background process (daemon) that will listen for changes in tiddlers returned by a filter/a set of filters and perform a set of actions whenever a change happens.
