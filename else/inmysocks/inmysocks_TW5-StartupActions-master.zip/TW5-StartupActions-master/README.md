# TW5-StartupActions
Some javascript for TiddlyWiki5 that triggers user defined actions (using action widgets) when the wiki is (re)loaded.
