TW5-NoLearningRequired-Full
===========================

The full collection of the no learning required TiddlyWikis

Each part/module/whatever a good name would be has a folder to itself inside the tiddlers folder. Any one of the folders should contain all the tiddlers needed for that function to be imported into another wiki.
The Dashboard isn't necessary, it just gives a unified interface for all of the other parts.
Some of the folders contain system tiddlers, they are there so that the first time you use the wiki there are some default values set, like hiding the sidebar and making sure that some menus are set by default.

By default there are no visible buttons on the tiddlers (no close, edit, etc.), but the button to show the sidebar is still there so you can change any of the settings normally to make the buttons visible.