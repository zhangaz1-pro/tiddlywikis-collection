/*\
created: 20180205162715434
type: application/javascript
title: $:/plugins/TheDiveO/ThirdFlow/ui/MoreSideBar/templates/new/library.js
modified: 20180207095013968
\*/
(function(){

/*jslint node: true, browser: true */
/*global $tw: false */
"use strict";

/* Exports/exposes symbols that users of this library can later use
 * after require()'ing a reference to this library.
 */
exports.dofoo = function () {
};

})();
