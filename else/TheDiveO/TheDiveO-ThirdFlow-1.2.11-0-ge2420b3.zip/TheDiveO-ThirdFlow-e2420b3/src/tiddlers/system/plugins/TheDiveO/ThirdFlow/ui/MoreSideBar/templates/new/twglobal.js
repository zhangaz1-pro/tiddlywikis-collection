/*\
created: 20180211153224637
type: application/javascript
title: $:/plugins/TheDiveO/ThirdFlow/ui/MoreSideBar/templates/new/twglobal.js
modified: 20180211153304692
tags: 
\*/
function(){

/*jslint node: true, browser: true */
/*global $tw: false */
"use strict";

/* Exports to be added to the global $tw */
exports.foofoo = 42;
  
})();