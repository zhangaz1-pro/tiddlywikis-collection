/*\
created: 20180211152629856
type: application/javascript
title: $:/plugins/TheDiveO/ThirdFlow/ui/MoreSideBar/templates/new/twconfig.js
modified: 20180211155735719
tags: 
\*/
function(){

/*jslint node: true, browser: true */
/*global $tw: false */
"use strict";

/* Exports to be added to $tw.config */
exports.foofoo = 42;
exports.foobar = {};
  
})();