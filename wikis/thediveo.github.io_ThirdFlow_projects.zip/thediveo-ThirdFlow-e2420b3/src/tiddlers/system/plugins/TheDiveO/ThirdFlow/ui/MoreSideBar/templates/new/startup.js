/*\
created: 20180205163726933
title: $:/plugins/TheDiveO/ThirdFlow/ui/MoreSideBar/templates/new/startup.js
modified: 20180205164120901
type: application/javascript
module-type: startup
\*/
(function(){

/*jslint node: true, browser: true */
/*global $tw: false */
"use strict";

/* Names this startup module and tells TiddlyWiki to run it either
 * synchronously or asynchronously.
 */
exports.name = "foostartup";
exports.synchronous = true;

/* Optionally set the order of startup execution */
/* exports.after = ["story"]; */
/* Optionally set the platforms on which to be executed */
/* exports.platforms = ["browser"]; */

/* Runs this function during startup */
exports.startup = function() {
  /* do something here... */
};
  
})();